package com.even.assistant.engine;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.List;

public class IntentDispatcher {

    public enum ActionType {
        CONFIRM_CALL,
        CONFIRM_SMS,
        CONFIRM_SAVE_MEMORY,
        APP_LAUNCHED,
        MEDIA_ACTION,
        REMINDER_OR_TIMER,
        MULTI_STEP,
        DIAGNOSTICS_OPENED,
        SPEAK_ONLY
    }

    public static class DispatchResult {
        public ActionType type;
        public String spokenResponse;
        public String targetName;
        public String targetNumber;
        public String messageBody;
        public String memoryText;
        public Intent directIntent;
        public List<DispatchResult> subSteps;

        public DispatchResult(ActionType type, String spokenResponse) {
            this.type = type;
            this.spokenResponse = spokenResponse;
        }
    }

    public static DispatchResult dispatch(Context context, String query, MemoryManager memoryManager) {
        if (query == null || query.trim().isEmpty()) {
            return new DispatchResult(ActionType.SPEAK_ONLY, "Boss, main sun nahi paya. Kripya dobara bolein.");
        }

        String raw = query.trim();
        if (MultiStepCommandParser.isMultiStep(raw)) {
            List<String> steps = MultiStepCommandParser.parseSteps(raw);
            if (steps.size() > 1) {
                DispatchResult multiResult = new DispatchResult(ActionType.MULTI_STEP, 
                    "Boss, main dono commands sequentially execute kar raha hoon.");
                multiResult.subSteps = new ArrayList<>();
                for (String step : steps) {
                    multiResult.subSteps.add(dispatchSingle(context, step, memoryManager));
                }
                return multiResult;
            }
        }

        return dispatchSingle(context, raw, memoryManager);
    }

    private static DispatchResult dispatchSingle(Context context, String raw, MemoryManager memoryManager) {
        String lower = raw.toLowerCase().trim();

        if (lower.contains("birthday") || lower.contains("janamdin")) {
            if (GreetingHelper.isApril13Morning()) {
                return new DispatchResult(ActionType.SPEAK_ONLY, 
                    "Happy Birthday Boss! Aaj 13 April hai. Aapko janamdin ki bohot bohot badhai! Aapka din shandar rahe.");
            } else {
                return new DispatchResult(ActionType.SPEAK_ONLY, 
                    "Boss, aapka janamdin 13 April ko hota hai. Aaj nahi hai, par jab aayega tab main sabse pehle wish karunga!");
            }
        }

        if (lower.contains("timer") || lower.contains("alarm") || lower.contains("reminder") || lower.contains("yaad dilana")) {
            ReminderHelper.ReminderResult rem = ReminderHelper.handleReminderQuery(context, raw);
            if (rem.success && rem.intent != null) {
                DispatchResult res = new DispatchResult(ActionType.REMINDER_OR_TIMER, rem.spokenResponse);
                res.directIntent = rem.intent;
                return res;
            }
        }

        String candidateMemory = MemoryManager.extractMemoryCandidate(raw);
        if (candidateMemory != null) {
            DispatchResult result = new DispatchResult(ActionType.CONFIRM_SAVE_MEMORY, 
                "Boss, kya main aapki memory me ye save kar lu: \"" + candidateMemory + "\"?");
            result.memoryText = candidateMemory;
            return result;
        }

        if (lower.contains("yaadein dikhao") || lower.contains("show memory") || lower.contains("kya yaad hai")) {
            if (memoryManager != null && !memoryManager.getAllMemories().isEmpty()) {
                StringBuilder sb = new StringBuilder("Boss, mujhe ye batein yaad hain:\n");
                for (String m : memoryManager.getAllMemories()) {
                    sb.append("• ").append(m).append("\n");
                }
                return new DispatchResult(ActionType.SPEAK_ONLY, sb.toString().trim());
            } else {
                return new DispatchResult(ActionType.SPEAK_ONLY, "Boss, abhi tak koi memory save nahi ki gayi hai.");
            }
        }

        if (lower.contains("call") || lower.contains("phone karo") || lower.contains("phone lagao")) {
            String target = extractCallTarget(lower);
            String resolvedNumber = resolveContactNumber(context, target);
            DispatchResult result = new DispatchResult(ActionType.CONFIRM_CALL,
                "Boss, " + target + (resolvedNumber != null ? " (" + resolvedNumber + ")" : "") + " ko call lagana hai? Confirm karein?");
            result.targetName = target;
            result.targetNumber = resolvedNumber != null ? resolvedNumber : target;
            return result;
        }

        if (lower.contains("message") || lower.contains("sms") || lower.contains("msg")) {
            String[] parts = extractMessageParts(raw);
            String recipient = parts[0];
            String body = parts[1];
            String resolvedNumber = resolveContactNumber(context, recipient);
            DispatchResult result = new DispatchResult(ActionType.CONFIRM_SMS,
                "Boss, " + recipient + " ko ye message bhejna hai: \"" + body + "\". Confirm karein?");
            result.targetName = recipient;
            result.targetNumber = resolvedNumber != null ? resolvedNumber : recipient;
            result.messageBody = body;
            return result;
        }

        if (lower.contains("youtube") || lower.contains("yt")) {
            Intent intent = getLaunchIntentForPackage(context, "com.google.android.youtube");
            if (intent == null) intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com"));
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, YouTube khol raha hoon.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("whatsapp")) {
            Intent intent = getLaunchIntentForPackage(context, "com.whatsapp");
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, WhatsApp open ho raha hai.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("telegram")) {
            Intent intent = getLaunchIntentForPackage(context, "org.telegram.messenger");
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, Telegram open kar raha hoon.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("instagram") || lower.contains("insta")) {
            Intent intent = getLaunchIntentForPackage(context, "com.instagram.android");
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, Instagram open ho raha hai.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("facebook") || lower.contains("fb")) {
            Intent intent = getLaunchIntentForPackage(context, "com.facebook.katana");
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, Facebook open ho raha hai.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("chrome") || lower.contains("browser") || lower.contains("google")) {
            Intent intent = getLaunchIntentForPackage(context, "com.android.chrome");
            if (intent == null) intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com"));
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, Chrome browser khol raha hoon.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("camera") || lower.contains("photo khicho")) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, Camera khul raha hai.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("maps") || lower.contains("map") || lower.contains("rasta")) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=home"));
            DispatchResult res = new DispatchResult(ActionType.APP_LAUNCHED, "Boss, Google Maps open kar raha hoon.");
            res.directIntent = intent;
            return res;
        }

        if (lower.contains("gaana bajao") || lower.contains("play music") || lower.contains("play song")) {
            simulateMediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY);
            return new DispatchResult(ActionType.MEDIA_ACTION, "Boss, Music play ho raha hai.");
        }

        if (lower.contains("gaana roko") || lower.contains("stop music") || lower.contains("pause")) {
            simulateMediaKey(context, KeyEvent.KEYCODE_MEDIA_PAUSE);
            return new DispatchResult(ActionType.MEDIA_ACTION, "Boss, Music pause kar diya gaya hai.");
        }

        if (lower.contains("volume badhao") || lower.contains("awaz badhao")) {
            adjustVolume(context, AudioManager.ADJUST_RAISE);
            return new DispatchResult(ActionType.MEDIA_ACTION, "Boss, Volume badha di gayi hai.");
        }

        if (lower.contains("volume kam karo") || lower.contains("volume ghatao")) {
            adjustVolume(context, AudioManager.ADJUST_LOWER);
            return new DispatchResult(ActionType.MEDIA_ACTION, "Boss, Volume kam kar di gayi hai.");
        }

        return new DispatchResult(ActionType.SPEAK_ONLY, 
            "Ji Boss, maine suna: \"" + raw + "\". Ye command register ho gayi hai.");
    }

    private static String extractCallTarget(String lower) {
        String clean = lower
            .replace("ko call lagao", "").replace("ko call karo", "")
            .replace("call lagao", "").replace("call karo", "").replace("call", "").trim();
        if (clean.isEmpty()) return "Maa";
        return clean.substring(0, 1).toUpperCase() + clean.substring(1);
    }

    private static String[] extractMessageParts(String raw) {
        String recipient = "Admin";
        String body = "Hello";
        if (raw.contains(":")) {
            String[] splits = raw.split(":", 2);
            recipient = splits[0].replaceAll("(?i)(message|bhejo|karo|ko|send|sms)", "").trim();
            body = splits[1].trim();
        } else {
            String lower = raw.toLowerCase();
            if (lower.contains("admin")) recipient = "Admin";
            else if (lower.contains("maa")) recipient = "Maa";
            body = raw;
        }
        if (recipient.isEmpty()) recipient = "Admin";
        return new String[]{recipient, body};
    }

    private static Intent getLaunchIntentForPackage(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        return pm.getLaunchIntentForPackage(packageName);
    }

    private static String resolveContactNumber(Context context, String name) {
        try {
            Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
            String[] projection = new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER};
            String selection = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?";
            String[] selectionArgs = new String[]{"%" + name + "%"};
            Cursor cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    int numIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    if (numIndex != -1) {
                        String number = cursor.getString(numIndex);
                        cursor.close();
                        return number;
                    }
                }
                cursor.close();
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static void simulateMediaKey(Context context, int keyCode) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            KeyEvent down = new KeyEvent(KeyEvent.ACTION_DOWN, keyCode);
            KeyEvent up = new KeyEvent(KeyEvent.ACTION_UP, keyCode);
            am.dispatchMediaKeyEvent(down);
            am.dispatchMediaKeyEvent(up);
        }
    }

    private static void adjustVolume(Context context, int direction) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
        }
    }
}