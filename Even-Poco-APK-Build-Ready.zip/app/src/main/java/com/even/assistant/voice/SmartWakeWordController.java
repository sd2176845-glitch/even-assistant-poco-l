package com.even.assistant.voice;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import java.util.ArrayList;

public class SmartWakeWordController {

    private static final String TAG = "EVEN_WAKE_WORD";

    public interface WakeWordListener {
        void onWakeWordDetected(String detectedPhrase);
        void onCommandReceived(String fullCommand);
        void onRmsLevelChanged(float rmsdB);
        void onWakeStateChanged(boolean isListeningForWakeWord, boolean isListeningForCommand);
    }

    private final Context context;
    private final WakeWordListener listener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private SpeechRecognizer speechRecognizer;
    private boolean isContinuousWakeActive = false;
    private boolean isAwaitingCommand = false;
    private int consecutiveErrorCount = 0;
    private static final int MAX_ERROR_BACKOFF_MS = 2500;

    private static final String[] WAKE_WORDS = {
        "hey even", "even sun", "even suno", "even, sun", "hello even", "suno even", "even"
    };

    public SmartWakeWordController(Context context, WakeWordListener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    public synchronized void startContinuousWakeDetection() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e(TAG, "SpeechRecognizer unavailable on device");
            return;
        }

        isContinuousWakeActive = true;
        isAwaitingCommand = false;
        consecutiveErrorCount = 0;
        rearmListening();
    }

    public synchronized void stopContinuousWakeDetection() {
        isContinuousWakeActive = false;
        isAwaitingCommand = false;
        mainHandler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
            speechRecognizer = null;
        }
        if (listener != null) {
            listener.onWakeStateChanged(false, false);
        }
    }

    private synchronized void rearmListening() {
        if (!isContinuousWakeActive) return;

        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
            speechRecognizer = null;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                consecutiveErrorCount = 0;
                if (listener != null) {
                    listener.onWakeStateChanged(!isAwaitingCommand, isAwaitingCommand);
                }
            }

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float rmsdB) {
                if (listener != null) listener.onRmsLevelChanged(rmsdB);
            }

            @Override
            public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                consecutiveErrorCount++;
                long delay = Math.min(consecutiveErrorCount * 400L, MAX_ERROR_BACKOFF_MS);
                if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) {
                    delay = 150L;
                }
                if (isContinuousWakeActive) {
                    mainHandler.postDelayed(() -> rearmListening(), delay);
                }
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String recognized = matches.get(0).trim();
                    handleHeardText(recognized);
                } else {
                    if (isContinuousWakeActive) {
                        mainHandler.postDelayed(() -> rearmListening(), 100L);
                    }
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                ArrayList<String> partials = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (partials != null && !partials.isEmpty()) {
                    String partial = partials.get(0).toLowerCase();
                    if (!isAwaitingCommand && checkWakeWordMatch(partial)) {
                        handleWakeWordTrigger(partial);
                    }
                }
            }

            @Override
            public void onEvent(int eventType, Bundle params) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);

        try {
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            mainHandler.postDelayed(() -> rearmListening(), 800L);
        }
    }

    private void handleHeardText(String text) {
        String lower = text.toLowerCase().trim();

        if (isAwaitingCommand) {
            isAwaitingCommand = false;
            if (listener != null) listener.onCommandReceived(text);
            mainHandler.postDelayed(() -> rearmListening(), 1200L);
            return;
        }

        if (checkWakeWordMatch(lower)) {
            String remainder = extractCommandRemainder(lower);
            if (remainder != null && !remainder.isEmpty()) {
                if (listener != null) {
                    listener.onWakeWordDetected(text);
                    listener.onCommandReceived(remainder);
                }
                mainHandler.postDelayed(() -> rearmListening(), 1500L);
            } else {
                handleWakeWordTrigger(text);
            }
        } else {
            if (isContinuousWakeActive) {
                mainHandler.postDelayed(() -> rearmListening(), 100L);
            }
        }
    }

    private void handleWakeWordTrigger(String rawWake) {
        isAwaitingCommand = true;
        if (listener != null) listener.onWakeWordDetected(rawWake);
        mainHandler.postDelayed(() -> rearmListening(), 1000L);
    }

    private boolean checkWakeWordMatch(String text) {
        for (String w : WAKE_WORDS) {
            if (text.startsWith(w) || text.contains(w)) return true;
        }
        return false;
    }

    private String extractCommandRemainder(String text) {
        for (String w : WAKE_WORDS) {
            if (text.startsWith(w)) {
                return text.substring(w.length()).replaceAll("^[\\,\\.\\s]+", "").trim();
            }
        }
        return null;
    }
}