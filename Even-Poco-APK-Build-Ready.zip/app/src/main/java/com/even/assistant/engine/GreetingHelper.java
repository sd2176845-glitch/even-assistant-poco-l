package com.even.assistant.engine;

import java.util.Calendar;

public class GreetingHelper {

    public static boolean isApril13Morning() {
        Calendar cal = Calendar.getInstance();
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int hour = cal.get(Calendar.HOUR_OF_DAY);

        return (month == Calendar.APRIL && day == 13 && hour >= 5 && hour < 12);
    }

    public static String getGreeting() {
        if (isApril13Morning()) {
            return "Happy Birthday Boss! Aaj 13 April hai. Aapko janamdin ki dher saari shubhkaamnayein! EVEN aapki sewa me hamesha tayaar hai.";
        }

        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);

        if (hour >= 4 && hour < 12) {
            return "Shubh Prabhat Boss! Aaj aapke kya plans hain? Main tayaar hoon.";
        } else if (hour >= 12 && hour < 17) {
            return "Good Afternoon Boss! Sab kuch control me hai. Boliye kya hukum hai?";
        } else if (hour >= 17 && hour < 22) {
            return "Shubh Sandhya Boss! Din kaisa raha aapka? Main aapki madad ke liye hazir hoon.";
        } else {
            return "Boss, raat kaafi ho gayi hai. Agar koi zaroori kaam ho to batayein, warna aaraam kijiye.";
        }
    }

    public static String getQuickWakePrompt() {
        if (isApril13Morning()) {
            return "Happy Birthday Boss! Boliye, kya hukum hai?";
        }
        return "Haan Boss, bolo.";
    }
}