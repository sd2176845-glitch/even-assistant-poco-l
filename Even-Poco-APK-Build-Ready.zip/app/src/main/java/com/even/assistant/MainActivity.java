package com.even.assistant;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telephony.SmsManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.even.assistant.device.PocoDeviceHelper;
import com.even.assistant.engine.GreetingHelper;
import com.even.assistant.engine.IntentDispatcher;
import com.even.assistant.engine.MemoryManager;
import com.even.assistant.service.EvenVoiceService;
import com.even.assistant.ui.DiagnosticsActivity;
import com.even.assistant.ui.EvenAvatarView;
import com.even.assistant.voice.SmartWakeWordController;
import com.even.assistant.voice.SpeechRecognizerManager;
import com.even.assistant.voice.TtsManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQ_CODE = 2001;

    private EvenAvatarView avatarView;
    private TextView tvLiveStatus;
    private TextView tvTranscript;
    private TextView tvGreeting;
    private Button btnPushToTalk;
    private ImageButton btnOpenDiagnostics;

    private SpeechRecognizerManager speechManager;
    private SmartWakeWordController wakeWordController;
    private TtsManager ttsManager;
    private MemoryManager memoryManager;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Lockscreen Wake flags
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            );
        }

        setContentView(R.layout.activity_main);

        initViews();
        initManagers();
        checkAndRequestPermissions();
        startForegroundVoiceService();
        deliverStartupGreeting();
    }

    private void initViews() {
        avatarView = findViewById(R.id.avatarView);
        tvLiveStatus = findViewById(R.id.tvLiveStatus);
        tvTranscript = findViewById(R.id.tvTranscript);
        tvGreeting = findViewById(R.id.tvGreeting);
        btnPushToTalk = findViewById(R.id.btnPushToTalk);
        btnOpenDiagnostics = findViewById(R.id.btnOpenDiagnostics);

        tvGreeting.setText(GreetingHelper.getGreeting());

        btnOpenDiagnostics.setOnClickListener(v -> {
            Intent intent = new Intent(this, DiagnosticsActivity.class);
            startActivity(intent);
        });

        setupPushToTalk();
    }

    private void initManagers() {
        memoryManager = new MemoryManager(this);

        ttsManager = new TtsManager(this, new TtsManager.TtsListener() {
            @Override
            public void onSpeechStart(String text) {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.SPEAKING);
                    tvLiveStatus.setText(R.string.status_speaking);
                });
            }

            @Override
            public void onSpeechDone(String utteranceId) {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.IDLE);
                    tvLiveStatus.setText(R.string.status_idle);
                });
            }

            @Override
            public void onSpeechError(String utteranceId) {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.IDLE);
                    tvLiveStatus.setText(R.string.status_idle);
                });
            }
        });

        speechManager = new SpeechRecognizerManager(this, new SpeechRecognizerManager.SpeechCallback() {
            @Override
            public void onReady() {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.LISTENING);
                    tvLiveStatus.setText(R.string.status_listening);
                });
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                runOnUiThread(() -> avatarView.setAudioRms(rmsdB));
            }

            @Override
            public void onResult(String text) {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.PROCESSING);
                    tvLiveStatus.setText(R.string.status_processing);
                    tvTranscript.setText("Boss: \"" + text + "\"");
                    handleVoiceCommand(text);
                });
            }

            @Override
            public void onError(int errorCode, String errorMessage) {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.IDLE);
                    tvLiveStatus.setText(R.string.status_idle);
                    tvTranscript.setText("EVEN: " + errorMessage);
                });
            }

            @Override
            public void onListeningStopped() {
                runOnUiThread(() -> {
                    if (avatarView != null) avatarView.setAudioRms(0f);
                });
            }
        });

        wakeWordController = new SmartWakeWordController(this, new SmartWakeWordController.WakeWordListener() {
            @Override
            public void onWakeWordDetected(String detectedPhrase) {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.SPEAKING);
                    tvLiveStatus.setText("Wake-Word Detected! (\"" + detectedPhrase + "\")");
                    tvTranscript.setText("EVEN: \"Haan Boss, bolo.\"");
                    ttsManager.speak("Haan Boss, bolo.");
                });
            }

            @Override
            public void onCommandReceived(String fullCommand) {
                runOnUiThread(() -> {
                    avatarView.setState(EvenAvatarView.AvatarState.PROCESSING);
                    tvLiveStatus.setText(R.string.status_processing);
                    tvTranscript.setText("Boss: \"" + fullCommand + "\"");
                    handleVoiceCommand(fullCommand);
                });
            }

            @Override
            public void onRmsLevelChanged(float rmsdB) {
                runOnUiThread(() -> avatarView.setAudioRms(rmsdB));
            }

            @Override
            public void onWakeStateChanged(boolean isListeningForWakeWord, boolean isListeningForCommand) {
                runOnUiThread(() -> {
                    if (isListeningForCommand) {
                        tvLiveStatus.setText("Listening for command, Boss…");
                    } else if (isListeningForWakeWord) {
                        tvLiveStatus.setText("Say 'Hey Even' or Hold to Talk");
                    }
                });
            }
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupPushToTalk() {
        btnPushToTalk.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (hasMicPermission()) {
                        btnPushToTalk.setText(R.string.release_to_send);
                        ttsManager.stop();
                        if (wakeWordController != null) wakeWordController.stopContinuousWakeDetection();
                        speechManager.startListening();
                    } else {
                        requestPermissionsExplicitly();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    btnPushToTalk.setText(R.string.push_to_talk);
                    speechManager.stopListening();
                    return true;
            }
            return false;
        });
    }

    private void handleVoiceCommand(String command) {
        IntentDispatcher.DispatchResult result = IntentDispatcher.dispatch(this, command, memoryManager);
        executeDispatchResult(result);
    }

    private void executeDispatchResult(IntentDispatcher.DispatchResult result) {
        switch (result.type) {
            case MULTI_STEP:
                ttsManager.speak(result.spokenResponse);
                tvTranscript.append("\n\nEVEN: " + result.spokenResponse);
                if (result.subSteps != null) {
                    long delay = 1200L;
                    for (IntentDispatcher.DispatchResult step : result.subSteps) {
                        mainHandler.postDelayed(() -> executeDispatchResult(step), delay);
                        delay += 1600L;
                    }
                }
                break;

            case CONFIRM_CALL:
                showCallConfirmationDialog(result.targetName, result.targetNumber, result.spokenResponse);
                break;

            case CONFIRM_SMS:
                showSmsConfirmationDialog(result.targetName, result.targetNumber, result.messageBody, result.spokenResponse);
                break;

            case CONFIRM_SAVE_MEMORY:
                showMemoryConfirmationDialog(result.memoryText, result.spokenResponse);
                break;

            case REMINDER_OR_TIMER:
            case APP_LAUNCHED:
                ttsManager.speak(result.spokenResponse);
                tvTranscript.append("\n\nEVEN: " + result.spokenResponse);
                if (result.directIntent != null) {
                    try {
                        startActivity(result.directIntent);
                    } catch (Exception e) {
                        Toast.makeText(this, "Action could not be opened on device", Toast.LENGTH_SHORT).show();
                    }
                }
                break;

            case MEDIA_ACTION:
            case SPEAK_ONLY:
            default:
                ttsManager.speak(result.spokenResponse);
                tvTranscript.append("\n\nEVEN: " + result.spokenResponse);
                break;
        }
    }

    private void showCallConfirmationDialog(String name, String number, String prompt) {
        ttsManager.speak(prompt);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_confirmation);

        TextView tvTitle = dialog.findViewById(R.id.tvDialogTitle);
        TextView tvMsg = dialog.findViewById(R.id.tvDialogMessage);
        Button btnCancel = dialog.findViewById(R.id.btnDialogCancel);
        Button btnConfirm = dialog.findViewById(R.id.btnDialogConfirm);

        tvTitle.setText(R.string.confirm_call_title);
        tvMsg.setText(getString(R.string.confirm_call_msg, name, number));

        btnCancel.setOnClickListener(v -> {
            dialog.dismiss();
            ttsManager.speak("Call cancel kar diya gaya hai Boss.");
        });

        btnConfirm.setOnClickListener(v -> {
            dialog.dismiss();
            performCall(number);
        });

        dialog.show();
    }

    private void performCall(String number) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            try {
                Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
                startActivity(callIntent);
            } catch (Exception e) {
                Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                startActivity(dialIntent);
            }
        } else {
            Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
            startActivity(dialIntent);
        }
    }

    private void showSmsConfirmationDialog(String name, String number, String body, String prompt) {
        ttsManager.speak(prompt);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_confirmation);

        TextView tvTitle = dialog.findViewById(R.id.tvDialogTitle);
        TextView tvMsg = dialog.findViewById(R.id.tvDialogMessage);
        Button btnCancel = dialog.findViewById(R.id.btnDialogCancel);
        Button btnConfirm = dialog.findViewById(R.id.btnDialogConfirm);

        tvTitle.setText(R.string.confirm_sms_title);
        tvMsg.setText(getString(R.string.confirm_sms_msg, name, body));

        btnCancel.setOnClickListener(v -> {
            dialog.dismiss();
            ttsManager.speak("Message cancel ho gaya Boss.");
        });

        btnConfirm.setOnClickListener(v -> {
            dialog.dismiss();
            sendSms(number, body);
        });

        dialog.show();
    }

    private void sendSms(String number, String body) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(number, null, body, null, null);
                ttsManager.speak("Message successfully send ho gaya Boss!");
                Toast.makeText(this, "SMS Sent to " + number, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number));
                smsIntent.putExtra("sms_body", body);
                startActivity(smsIntent);
            }
        } else {
            Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number));
            smsIntent.putExtra("sms_body", body);
            startActivity(smsIntent);
        }
    }

    private void showMemoryConfirmationDialog(String memoryText, String prompt) {
        ttsManager.speak(prompt);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_confirmation);

        TextView tvTitle = dialog.findViewById(R.id.tvDialogTitle);
        TextView tvMsg = dialog.findViewById(R.id.tvDialogMessage);
        Button btnCancel = dialog.findViewById(R.id.btnDialogCancel);
        Button btnConfirm = dialog.findViewById(R.id.btnDialogConfirm);

        tvTitle.setText("Save to Memory Vault?");
        tvMsg.setText("Boss, kya aap chahte hain ki EVEN ise hamesha yaad rakhe:\n\n\"" + memoryText + "\"");

        btnCancel.setOnClickListener(v -> {
            dialog.dismiss();
            ttsManager.speak("Theek hai Boss, ise save nahi kiya gaya.");
        });

        btnConfirm.setOnClickListener(v -> {
            dialog.dismiss();
            memoryManager.addMemory(memoryText);
            ttsManager.speak("Maine yaad rakh liya hai Boss.");
            Toast.makeText(this, "Memory saved securely on-device", Toast.LENGTH_SHORT).show();
        });

        dialog.show();
    }

    private void deliverStartupGreeting() {
        String greeting = GreetingHelper.getGreeting();
        tvTranscript.postDelayed(() -> {
            if (ttsManager != null && ttsManager.isInitialized()) {
                ttsManager.speak(greeting);
            }
        }, 1200);
    }

    private void startForegroundVoiceService() {
        Intent serviceIntent = new Intent(this, EvenVoiceService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }

    private boolean hasMicPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void checkAndRequestPermissions() {
        List<String> needed = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CALL_PHONE);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.SEND_SMS);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_CONTACTS);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        }

        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), PERMISSION_REQ_CODE);
        }
    }

    private void requestPermissionsExplicitly() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQ_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQ_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                if (Manifest.permission.RECORD_AUDIO.equals(permissions[i])) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Microphone enabled for EVEN", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasMicPermission() && wakeWordController != null) {
            wakeWordController.startContinuousWakeDetection();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (wakeWordController != null) wakeWordController.stopContinuousWakeDetection();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechManager != null) speechManager.destroy();
        if (wakeWordController != null) wakeWordController.stopContinuousWakeDetection();
        if (ttsManager != null) ttsManager.destroy();
    }
}