package com.even.assistant.engine;

import android.content.Context;
import android.content.Intent;
import android.provider.AlarmClock;
import android.provider.CalendarContract;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReminderHelper {

    public static class ReminderResult {
        public boolean success;
        public Intent intent;
        public String spokenResponse;

        public ReminderResult(boolean success, Intent intent, String spokenResponse) {
            this.success = success;
            this.intent = intent;
            this.spokenResponse = spokenResponse;
        }
    }

    public static ReminderResult handleReminderQuery(Context context, String query) {
        String lower = query.toLowerCase().trim();

        if (lower.contains("timer")) {
            int seconds = extractTimerSeconds(lower);
            if (seconds > 0) {
                Intent timerIntent = new Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "EVEN Timer for Boss")
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                int minutes = seconds / 60;
                String msg = minutes > 0
                        ? "Boss, " + minutes + " minute ka timer set kar diya gaya hai."
                        : "Boss, " + seconds + " second ka timer set ho gaya hai.";

                return new ReminderResult(true, timerIntent, msg);
            }
        }

        if (lower.contains("alarm")) {
            int[] time = extractAlarmTime(lower);
            int hour = time[0];
            int minutes = time[1];

            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "EVEN Alarm for Boss")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            String formattedTime = String.format("%02d:%02d", hour, minutes);
            return new ReminderResult(true, alarmIntent, "Boss, " + formattedTime + " ka alarm schedule kar diya gaya hai.");
        }

        if (lower.contains("reminder") || lower.contains("yaad dilana")) {
            String title = query.replaceFirst("(?i)(reminder|lagao|set|karo|yaad dilana|ki)", "").trim();
            if (title.isEmpty()) title = "Important Note for Boss";

            Calendar beginTime = Calendar.getInstance();
            beginTime.add(Calendar.HOUR_OF_DAY, 1);

            Intent calIntent = new Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginTime.getTimeInMillis())
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            return new ReminderResult(true, calIntent, "Boss, reminder create ho raha hai: \"" + title + "\"");
        }

        return new ReminderResult(false, null, "Boss, timer ya alarm ka time samajh nahi aaya.");
    }

    private static int extractTimerSeconds(String text) {
        Pattern p = Pattern.compile("(\\d+)\\s*(minute|min|sec|second|ghante|hour)?");
        Matcher m = p.matcher(text);
        if (m.find()) {
            try {
                int value = Integer.parseInt(m.group(1));
                String unit = m.group(2) != null ? m.group(2) : "minute";
                if (unit.contains("sec")) return value;
                if (unit.contains("hour") || unit.contains("ghante")) return value * 3600;
                return value * 60;
            } catch (Exception ignored) {}
        }
        return 300;
    }

    private static int[] extractAlarmTime(String text) {
        int hour = 7;
        int minute = 0;
        Pattern p = Pattern.compile("(\\d{1,2})(:(\\d{2}))?\\s*(baje|am|pm|subah|shaam|raat)?");
        Matcher m = p.matcher(text);
        if (m.find()) {
            try {
                hour = Integer.parseInt(m.group(1));
                if (m.group(3) != null) minute = Integer.parseInt(m.group(3));
                String modifier = m.group(4) != null ? m.group(4) : "";
                if ((modifier.contains("pm") || modifier.contains("shaam") || modifier.contains("raat")) && hour < 12) {
                    hour += 12;
                }
            } catch (Exception ignored) {}
        }
        return new int[]{hour, minute};
    }
}