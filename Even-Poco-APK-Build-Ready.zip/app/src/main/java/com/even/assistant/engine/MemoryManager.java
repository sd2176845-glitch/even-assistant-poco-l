package com.even.assistant.engine;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class MemoryManager {

    private static final String PREF_NAME = "even_private_memory";
    private static final String KEY_MEMORIES = "boss_memories";
    private final SharedPreferences prefs;

    public MemoryManager(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public synchronized List<String> getAllMemories() {
        List<String> list = new ArrayList<>();
        String json = prefs.getString(KEY_MEMORIES, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                list.add(arr.getString(i));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

    public synchronized void addMemory(String item) {
        if (item == null || item.trim().isEmpty()) return;
        List<String> current = getAllMemories();
        current.add(item.trim());
        saveList(current);
    }

    public synchronized boolean deleteMemory(int index) {
        List<String> current = getAllMemories();
        if (index >= 0 && index < current.size()) {
            current.remove(index);
            saveList(current);
            return true;
        }
        return false;
    }

    public synchronized void clearAll() {
        prefs.edit().remove(KEY_MEMORIES).apply();
    }

    public static String extractMemoryCandidate(String speech) {
        if (speech == null) return null;
        String lower = speech.toLowerCase().trim();

        String[] triggers = {
            "yaad rakhna ki", "yaad rakhna", "yaad rakho ki", "yaad rakho",
            "remember that", "remember", "note kar lo ki", "note kar lo"
        };

        for (String trigger : triggers) {
            if (lower.startsWith(trigger)) {
                String candidate = speech.substring(trigger.length()).trim();
                if (candidate.startsWith("ki ")) candidate = candidate.substring(3).trim();
                return candidate.length() > 2 ? candidate : null;
            }
        }
        return null;
    }

    private void saveList(List<String> list) {
        JSONArray arr = new JSONArray();
        for (String item : list) arr.put(item);
        prefs.edit().putString(KEY_MEMORIES, arr.toString()).apply();
    }
}