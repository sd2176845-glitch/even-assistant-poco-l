package com.even.assistant.engine;

import java.util.ArrayList;
import java.util.List;

public class MultiStepCommandParser {

    private static final String[] CONJUNCTIONS = {
        "\\s+aur\\s+", "\\s+and\\s+", "\\s+fir\\s+", "\\s+then\\s+", "\\s+uske baad\\s+"
    };

    public static List<String> parseSteps(String query) {
        List<String> steps = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) return steps;

        String normalized = query.trim();
        for (String conj : CONJUNCTIONS) {
            normalized = normalized.replaceAll("(?i)" + conj, " ___STEP_SPLIT___ ");
        }

        String[] parts = normalized.split("___STEP_SPLIT___");
        for (String part : parts) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) steps.add(trimmed);
        }
        return steps;
    }

    public static boolean isMultiStep(String query) {
        return parseSteps(query).size() > 1;
    }
}