package com.even.assistant.device;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

public class RealmeDeviceHelper {

    public static boolean isRealmeDevice() {
        String brand = Build.BRAND != null ? Build.BRAND.toLowerCase() : "";
        String manufacturer = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase() : "";
        return brand.contains("realme") || manufacturer.contains("realme") || brand.contains("oppo");
    }

    public static boolean openRealmeAutoLaunch(Context context) {
        Intent intent = new Intent();
        String[][] realmeComponents = {
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
            {"com.oplus.battery", "com.oplus.battery.AppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.PermissionManagerActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"}
        };

        for (String[] comp : realmeComponents) {
            try {
                intent.setComponent(new ComponentName(comp[0], comp[1]));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return true;
            } catch (Exception ignored) {}
        }

        try {
            Intent appSettings = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            appSettings.setData(Uri.parse("package:" + context.getPackageName()));
            appSettings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(appSettings);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}