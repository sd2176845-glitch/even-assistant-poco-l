package com.even.assistant.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

public class EvenAvatarView extends View {

    public enum AvatarState {
        IDLE,
        LISTENING,
        PROCESSING,
        SPEAKING
    }

    private AvatarState currentState = AvatarState.IDLE;
    private float audioRms = 0f;
    private float animationPhase = 0f;

    private Paint corePaint;
    private Paint ringPaint;
    private Paint particlePaint;

    public EvenAvatarView(Context context) {
        super(context);
        init();
    }

    public EvenAvatarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(3f);
        ringPaint.setColor(Color.parseColor("#00E5FF"));

        particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        particlePaint.setColor(Color.parseColor("#80D8FF"));
    }

    public void setState(AvatarState state) {
        this.currentState = state;
        postInvalidateOnAnimation();
    }

    public void setAudioRms(float rms) {
        this.audioRms = Math.max(0f, rms);
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float baseRadius = Math.min(cx, cy) * 0.45f;
        animationPhase += 0.05f;

        float dynamicScale = 1.0f;
        if (currentState == AvatarState.LISTENING) {
            dynamicScale = 1.0f + (audioRms / 15f);
        } else if (currentState == AvatarState.SPEAKING) {
            dynamicScale = 1.0f + 0.15f * (float) Math.sin(animationPhase * 2.5);
        } else if (currentState == AvatarState.PROCESSING) {
            dynamicScale = 0.95f + 0.05f * (float) Math.cos(animationPhase * 4.0);
        } else {
            dynamicScale = 1.0f + 0.04f * (float) Math.sin(animationPhase);
        }

        float coreRadius = baseRadius * dynamicScale;

        RadialGradient gradient = new RadialGradient(
                cx, cy, coreRadius * 1.6f,
                new int[]{
                    Color.parseColor("#E000E5FF"),
                    Color.parseColor("#660091EA"),
                    Color.TRANSPARENT
                },
                new float[]{0.1f, 0.6f, 1.0f},
                Shader.TileMode.CLAMP
        );
        corePaint.setShader(gradient);
        canvas.drawCircle(cx, cy, coreRadius * 1.6f, corePaint);

        for (int i = 1; i <= 3; i++) {
            float ringR = coreRadius * (0.8f + i * 0.28f);
            float alpha = (float) Math.abs(Math.sin(animationPhase + (i * 0.8))) * 180 + 40;
            ringPaint.setAlpha((int) Math.min(255, alpha));
            canvas.drawCircle(cx, cy, ringR, ringPaint);
        }

        int particleCount = 8;
        for (int i = 0; i < particleCount; i++) {
            double angle = animationPhase * (currentState == AvatarState.PROCESSING ? 3.0 : 1.0) + (i * (2 * Math.PI / particleCount));
            float dist = coreRadius * 1.4f + (float) Math.sin(animationPhase * 2 + i) * 12f;
            float px = cx + (float) (Math.cos(angle) * dist);
            float py = cy + (float) (Math.sin(angle) * dist);
            canvas.drawCircle(px, py, 4f, particlePaint);
        }

        postInvalidateOnAnimation();
    }
}